library("table1")

descriptiveStatisticsMunich2019dataset <- function() {
                                       table1::table1(~factor(Sex) + factor(cHsp70_level_high1_low0) | Age, data=Munich2019dataset)
                                       }

